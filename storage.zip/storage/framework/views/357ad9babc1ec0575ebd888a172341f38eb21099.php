<?php /* C:\xampp\htdocs\DevOps_v2\resources\views/email/fields.blade.php */ ?>
<!-- Template Name Field -->
 
<script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script> 
<script type="text/javascript">
//<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
</script>

<div class="form-group col-sm-12">
    <?php echo Form::label('template_name', 'Template Name:'); ?>

    <?php echo Form::text('template_name', null, ['class' => 'form-control','required'=>'required', 'placeholder'=>'Enter the Template name For your Reference']); ?>

</div>


<div class="form-group col-sm-12">
    <?php echo Form::label('description', 'Activity Description:'); ?>

    <?php echo e('No Of Available Description is: '.count($get_description)); ?>

    <select name="activity_description" class="form-control">
        <?php
          $i=1;
          foreach ($get_description as $key1 => $value1) {
                   echo '<option  value="'.$value1->activity_description.'">'.$i.'.'.$value1->activity_description.'</option>';
                   $i=$i+1;
          }
        ?>
    </select>
  
</div>

<!-- Subject Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('subject', 'Subject:'); ?>

    <?php echo Form::text('subject', null, ['class' => 'form-control','placeholder'=>'Subject of the Mail' ,'required'=>'required']); ?>

</div>

<!-- Message Field -->

<div class="form-group col-sm-12">
    <?php echo Form::label('message', 'Message:'); ?>

     <textarea name="message" class="form-control"  required="required">DevOps Always Ultimate </textarea>

</div>
<div class="form-group col-sm-12">
    <?php echo Form::label('attachment_path', 'Attachment File Name:'); ?>

    <?php echo Form::text('attachment_path', "", ['class' => 'form-control', 'placeholder'=>'Just give the filename', 'required'=>'required']); ?>

    <span style="color: red;">Note: Just enter the file name only  </span><br>
    <span style="color: red;">Note: you can put the file in this path  <?php echo e(storage_path('email')); ?> </span>
</div>



<!-- Submit Field -->
<div class=" col-sm-6" align="center">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('home'); ?>" class="btn btn-primary">Cancel</a>
</div>