<?php /* C:\xampp\htdocs\DevOps_v2\resources\views/email/create_new.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<div class="container">
      <div class="row">
    <div class="col-md-3"></div>
    <div align="center" class="col-md-6">
         <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <?php echo e(session()->get('success')); ?>


    </div>
     <?php endif; ?>
       <?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <?php echo session()->get('error'); ?>

    </div>
     <?php endif; ?>
     <div class="col-md-3"></div>
     </div>
   
    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Create New Templates</div>

                <div class="card-body">
                   
                     <?php echo Form::open(['route' => 'store.email.template','method'=>'post']); ?>


                        <?php echo $__env->make('email.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo Form::close(); ?>

                <?php
              
                ?>
             
                </div>

            </div>
                   

</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>